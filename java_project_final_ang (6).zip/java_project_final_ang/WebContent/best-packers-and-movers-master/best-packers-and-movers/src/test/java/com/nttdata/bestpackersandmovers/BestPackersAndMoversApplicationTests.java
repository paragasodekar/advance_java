package com.nttdata.bestpackersandmovers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BestPackersAndMoversApplicationTests {

	@Test
	void contextLoads() {
	}

}
