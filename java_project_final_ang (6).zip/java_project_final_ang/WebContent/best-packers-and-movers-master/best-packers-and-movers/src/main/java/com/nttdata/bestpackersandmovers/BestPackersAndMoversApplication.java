package com.nttdata.bestpackersandmovers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BestPackersAndMoversApplication {

	public static void main(String[] args) {
		SpringApplication.run(BestPackersAndMoversApplication.class, args);
	}

}
