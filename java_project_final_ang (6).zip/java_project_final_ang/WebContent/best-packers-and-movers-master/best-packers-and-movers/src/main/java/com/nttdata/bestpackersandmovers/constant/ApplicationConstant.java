package com.nttdata.bestpackersandmovers.constant;

public class ApplicationConstant {
	
	//just a comment
	//deleted files

}
