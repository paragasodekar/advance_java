package com.nttdata.bestpackersandmovers.util;

public class DummyUtil {

	//just a comment
}
