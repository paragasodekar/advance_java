# best-packers-and-movers
NTT Data Integration Academy team B project work.
